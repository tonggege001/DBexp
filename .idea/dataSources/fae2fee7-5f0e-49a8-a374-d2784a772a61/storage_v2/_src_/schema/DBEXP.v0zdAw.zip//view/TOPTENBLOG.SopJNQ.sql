create definer = tonggege@`%` view TOPTENBLOG as
select `DBEXP`.`MBLOG`.`BID`        AS `BID`,
       `DBEXP`.`MBLOG`.`TITLE`      AS `TITLE`,
       `DBEXP`.`MBLOG`.`UID`        AS `UID`,
       `DBEXP`.`USER`.`NAME`        AS `NAME`,
       count(`DBEXP`.`THUMB`.`UID`) AS `THUMBNUM`
from (`DBEXP`.`MBLOG`
         join `DBEXP`.`USER`
         join `DBEXP`.`THUMB`)
where ((`DBEXP`.`MBLOG`.`UID` = `DBEXP`.`USER`.`UID`) and (`DBEXP`.`THUMB`.`BID` = `DBEXP`.`MBLOG`.`BID`) and
       (`DBEXP`.`THUMB`.`UID` = `DBEXP`.`MBLOG`.`UID`) and (to_days(now()) = to_days(
            (((`DBEXP`.`MBLOG`.`PYEAR` * 10000) + (`DBEXP`.`MBLOG`.`PMONTH` * 100)) + `DBEXP`.`MBLOG`.`PDAY`))))
group by `DBEXP`.`MBLOG`.`BID`, `DBEXP`.`MBLOG`.`TITLE`, `DBEXP`.`MBLOG`.`UID`, `DBEXP`.`USER`.`NAME`
order by count(`DBEXP`.`THUMB`.`UID`) desc
limit 10;

